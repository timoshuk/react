import React from 'react';
import ReactDOM from 'react-dom';

const App = () => <p>Hello</p>;

ReactDOM.render(<App />,
  document.getElementById('root'));
