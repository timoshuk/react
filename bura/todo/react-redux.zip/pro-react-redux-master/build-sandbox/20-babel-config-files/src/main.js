class App {

  run() {
    const name = 'World';
    console.log(`Hello ${name}`);
  }
}

const app = new App();
app.run();