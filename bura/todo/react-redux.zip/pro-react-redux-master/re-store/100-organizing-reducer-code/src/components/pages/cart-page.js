import React from 'react';

const CartPage = () => {
  return <div>Cart Page</div>
};

export default CartPage;
