import HomePage from './home-page';
import CartPage from './cart-page';

export {
  HomePage,
  CartPage
};
