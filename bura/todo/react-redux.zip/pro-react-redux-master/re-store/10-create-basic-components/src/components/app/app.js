import React from 'react';
import './app.css';

const App = () => {
  return <div>App</div>;
};

export default App;
