import React from 'react';
import BookList from '../book-list';

const HomePage = () => {
  return (
    <BookList />
  );
};

export default HomePage;
